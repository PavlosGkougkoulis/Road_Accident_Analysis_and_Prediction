--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.1
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "RoadAccidents";
--
-- Name: RoadAccidents; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "RoadAccidents" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Greek_Greece.1253';


ALTER DATABASE "RoadAccidents" OWNER TO postgres;

\connect "RoadAccidents"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "RoadAccidents"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "RoadAccidents" IS 'A Database of road accidents in Greece and other yearly factors and indicators';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: monthly_accidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monthly_accidents (
    year integer NOT NULL,
    month integer NOT NULL,
    accidents integer,
    fatalities integer
);


ALTER TABLE public.monthly_accidents OWNER TO postgres;

--
-- Name: weekly_accidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weekly_accidents (
    year integer NOT NULL,
    month integer NOT NULL,
    week integer NOT NULL,
    accidents integer,
    fatalities integer
);


ALTER TABLE public.weekly_accidents OWNER TO postgres;

--
-- Name: yearly_accidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yearly_accidents (
    year integer NOT NULL,
    accidents integer,
    fatalities integer
);


ALTER TABLE public.yearly_accidents OWNER TO postgres;

--
-- Name: yearly_indicators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yearly_indicators (
    year integer NOT NULL,
    total_gdp numeric(10,3),
    gdp_per_capita numeric(10,3),
    unemployment numeric(10,1),
    population bigint,
    environmental_taxes numeric(10,3),
    vehicles bigint,
    petrol_cons numeric(10,3),
    ng_cons numeric(10,3),
    el_cons numeric(10,3),
    fatal_per_million_veh integer,
    speed_infr bigint,
    drink_infr bigint,
    belt_infr bigint,
    helmet_infr bigint,
    inflation_rate numeric(10,1),
    gini_index numeric(10,1)
);


ALTER TABLE public.yearly_indicators OWNER TO postgres;

--
-- Name: COLUMN yearly_indicators.year; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.year IS 'Current Year';


--
-- Name: COLUMN yearly_indicators.total_gdp; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.total_gdp IS 'Total Yearly GDP in Million Euros';


--
-- Name: COLUMN yearly_indicators.gdp_per_capita; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.gdp_per_capita IS 'Total Yearly GDP Per Capita';


--
-- Name: COLUMN yearly_indicators.unemployment; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.unemployment IS 'Total Yearly Unemployment in Thousands of People';


--
-- Name: COLUMN yearly_indicators.population; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.population IS 'Total Population of the Current Year';


--
-- Name: COLUMN yearly_indicators.environmental_taxes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.environmental_taxes IS 'Total Yearly Environmental Taxes in Million Euros';


--
-- Name: COLUMN yearly_indicators.vehicles; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.vehicles IS 'Total Yearly Number of Vehicles Existing';


--
-- Name: COLUMN yearly_indicators.petrol_cons; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.petrol_cons IS 'Total Yearly Petrol Consumption in Thousand Tonnes of Oil Equivalent';


--
-- Name: COLUMN yearly_indicators.ng_cons; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.ng_cons IS 'Total Yearly Natural Gas Consumption in Thousand Tonnes of Oil Equivalent			
';


--
-- Name: COLUMN yearly_indicators.el_cons; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.el_cons IS 'Total Yearly Electricity Consumption in Thousand Tonnes of Oil Equivalent			
';


--
-- Name: COLUMN yearly_indicators.fatal_per_million_veh; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.fatal_per_million_veh IS 'Total Yearly Fatalities per million vehicles';


--
-- Name: COLUMN yearly_indicators.speed_infr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.speed_infr IS 'Total Yearly Speed Infringements';


--
-- Name: COLUMN yearly_indicators.drink_infr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.drink_infr IS 'Total Yearly Drink & Drive Infringements';


--
-- Name: COLUMN yearly_indicators.belt_infr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.belt_infr IS 'Total Yearly Seat Belt Infringements';


--
-- Name: COLUMN yearly_indicators.helmet_infr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.helmet_infr IS 'Total Yearly Helmet Infringements';


--
-- Name: COLUMN yearly_indicators.inflation_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.inflation_rate IS 'Average Yearly Percentage of Inflation Rate ';


--
-- Name: COLUMN yearly_indicators.gini_index; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.yearly_indicators.gini_index IS 'Yearly Gini Index';


--
-- Data for Name: monthly_accidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monthly_accidents (year, month, accidents, fatalities) FROM stdin;
\.
COPY public.monthly_accidents (year, month, accidents, fatalities) FROM '$$PATH$$/4865.dat';

--
-- Data for Name: weekly_accidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weekly_accidents (year, month, week, accidents, fatalities) FROM stdin;
\.
COPY public.weekly_accidents (year, month, week, accidents, fatalities) FROM '$$PATH$$/4866.dat';

--
-- Data for Name: yearly_accidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yearly_accidents (year, accidents, fatalities) FROM stdin;
\.
COPY public.yearly_accidents (year, accidents, fatalities) FROM '$$PATH$$/4864.dat';

--
-- Data for Name: yearly_indicators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yearly_indicators (year, total_gdp, gdp_per_capita, unemployment, population, environmental_taxes, vehicles, petrol_cons, ng_cons, el_cons, fatal_per_million_veh, speed_infr, drink_infr, belt_infr, helmet_infr, inflation_rate, gini_index) FROM stdin;
\.
COPY public.yearly_indicators (year, total_gdp, gdp_per_capita, unemployment, population, environmental_taxes, vehicles, petrol_cons, ng_cons, el_cons, fatal_per_million_veh, speed_infr, drink_infr, belt_infr, helmet_infr, inflation_rate, gini_index) FROM '$$PATH$$/4863.dat';

--
-- Name: weekly_accidents PK_1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weekly_accidents
    ADD CONSTRAINT "PK_1" PRIMARY KEY (year, month, week) INCLUDE (year, month, week);


--
-- Name: monthly_accidents PK_2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_accidents
    ADD CONSTRAINT "PK_2" PRIMARY KEY (year, month) INCLUDE (year, month);


--
-- Name: yearly_accidents PK_3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yearly_accidents
    ADD CONSTRAINT "PK_3" PRIMARY KEY (year) INCLUDE (year);


--
-- Name: yearly_indicators PK_4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yearly_indicators
    ADD CONSTRAINT "PK_4" PRIMARY KEY (year);


--
-- Name: weekly_accidents FK_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weekly_accidents
    ADD CONSTRAINT "FK_1" FOREIGN KEY (year) REFERENCES public.yearly_accidents(year) NOT VALID;


--
-- Name: yearly_indicators FK_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yearly_indicators
    ADD CONSTRAINT "FK_1" FOREIGN KEY (year) REFERENCES public.yearly_accidents(year) NOT VALID;


--
-- Name: monthly_accidents FK_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_accidents
    ADD CONSTRAINT "FK_1" FOREIGN KEY (year) REFERENCES public.yearly_accidents(year) NOT VALID;


--
-- Name: weekly_accidents FK_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weekly_accidents
    ADD CONSTRAINT "FK_2" FOREIGN KEY (month, year) REFERENCES public.monthly_accidents(month, year) NOT VALID;


--
-- PostgreSQL database dump complete
--

